// Codul React complet cu formular, logo și traduceri va fi inserat aici manual după test
export default function LeanConstructIT() {
  return <div>Lean Construct IT</div>;
}
